package com.example.escola

import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import android.widget.EditText
import androidx.core.content.ContextCompat


class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_second)

        private fun calcularMedia() {
            // Obter valores das notas
            val nota1 = findViewById<EditText>(R.id.editNota1).text.toString().toDoubleOrNull() ?: 0.0
            val nota2 = findViewById<EditText>(R.id.editNota2).text.toString().toDoubleOrNull() ?: 0.0
            val nota3 = findViewById<EditText>(R.id.editNota3).text.toString().toDoubleOrNull() ?: 0.0

            // Calcular média
            val media = (nota1 + nota2 + nota3) / 3
            val mediaFormatada = "%.1f".format(media) // Formata com 1 casa decimal

            // Determinar situação
            val situacao = when {
                media < 4 -> {
                    "Reprovado ❌"
                }
                media >= 4 && media < 6 -> {
                    "Prova Sub!"
                }
                else -> {
                    "Aprovado ✅"
                }
            }

            // Exibir resultado
            val resultado = findViewById<TextView>(R.id.tvResultado)
            resultado.text = "Média: $mediaFormatada\n$situacao"

            // Mudar cor conforme situação
            when {
                media < 4 -> resultado.setTextColor(ContextCompat.getColor(this, android.R.color.holo_red_dark))
                media >= 4 && media < 6 -> resultado.setTextColor(ContextCompat.getColor(this, android.R.color.holo_orange_dark))
                else -> resultado.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_dark))
            }
        }
    }
}