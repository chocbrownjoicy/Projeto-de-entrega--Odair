package com.example.aprovao
import com.example.aprovao.SecondActivity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity




class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnVerificar = findViewById<Button>(R.id.Verificar_aprovacao)
        btnVerificar.setOnClickListener {
            // Verifique se o nome da classe está EXATAMENTE igual
            val intent = Intent(this, SecondActivity::class.java)
            startActivity(intent)

            // Adicione este log para debug
            println("DEBUG: Botão clicado - Intent disparada")
        }
    }
}