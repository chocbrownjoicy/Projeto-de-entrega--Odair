package com.example.aprovao

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        // Configurar o botão para calcular
        findViewById<Button>(R.id.btnCalcular).setOnClickListener {
            calcularMedia()
        }
    }

    fun calcularMedia() {
        try {
            val nota1 = findViewById<EditText>(R.id.editNota1).text.toString().toDoubleOrNull() ?: 0.0
            val nota2 = findViewById<EditText>(R.id.editNota2).text.toString().toDoubleOrNull() ?: 0.0
            val nota3 = findViewById<EditText>(R.id.editNota3).text.toString().toDoubleOrNull() ?: 0.0

            val media = (nota1 + nota2 + nota3) / 3
            val mediaFormatada = "%.1f".format(media)

            val situacao = when {
                media < 4 -> "Reprovado ❌"
                media < 6 -> "Prova Sub!"
                else -> "Aprovado ✅"
            }

            findViewById<TextView>(R.id.tvResultado).apply {
                text = "Média: $mediaFormatada\n$situacao"
                setTextColor(
                    when {
                        media < 4 -> ContextCompat.getColor(this@SecondActivity, android.R.color.holo_red_dark)
                        media < 6 -> ContextCompat.getColor(this@SecondActivity, android.R.color.holo_orange_dark)
                        else -> ContextCompat.getColor(this@SecondActivity, android.R.color.holo_green_dark)
                    }
                )
            }
        } catch (e: Exception) {
            findViewById<TextView>(R.id.tvResultado).text = "Erro no cálculo: ${e.message}"
        }
    }
}