package com.example.projeto

import android.content.Intent
import android.os.Bundle

import androidx.appcompat.app.AppCompatActivity
import com.example.projeto.segundaActivity
import com.example.projeto.segundaActivity as segundaActivity1


class MainActivity : AppCompatActivity() {
  

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)



    }
}